import React from 'react';
export function TaskableIcon({ className = '' }: {className?: string;}) {
  return (
    <svg
      viewBox="0 0 512 512"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Taskable App Icon: A friendly owl sitting on a checkmark"
      role="img">

      <defs>
        {/* Background Gradient */}
        <linearGradient id="bg-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#2EC4B6" />
          <stop offset="100%" stopColor="#1A9E8F" />
        </linearGradient>

        {/* Body Radial Gradient */}
        <radialGradient id="body-gradient" cx="50%" cy="40%" r="60%">
          <stop offset="0%" stopColor="#38D4C6" />
          <stop offset="70%" stopColor="#2EC4B6" />
          <stop offset="100%" stopColor="#178578" />
        </radialGradient>

        {/* Checkmark Gradient */}
        <linearGradient id="check-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFD166" />
          <stop offset="100%" stopColor="#FFB703" />
        </linearGradient>

        {/* Belly Pattern (Scallops) */}
        <pattern
          id="scallop"
          x="0"
          y="0"
          width="24"
          height="24"
          patternUnits="userSpaceOnUse">

          <path
            d="M 0 12 Q 12 24 24 12"
            fill="none"
            stroke="#F0E6D2"
            strokeWidth="2.5"
            strokeLinecap="round" />

        </pattern>

        {/* Drop Shadow */}
        <filter id="drop-shadow" x="-10%" y="-10%" width="130%" height="130%">
          <feDropShadow
            dx="0"
            dy="12"
            stdDeviation="16"
            floodColor="#000000"
            floodOpacity="0.15" />

        </filter>

        <filter id="inner-shadow" x="-20%" y="-20%" width="140%" height="140%">
          <feOffset dx="0" dy="-8" />
          <feGaussianBlur stdDeviation="6" result="offset-blur" />
          <feComposite
            operator="out"
            in="SourceGraphic"
            in2="offset-blur"
            result="inverse" />

          <feFlood floodColor="#1B2838" floodOpacity="0.08" result="color" />
          <feComposite operator="in" in="color" in2="inverse" result="shadow" />
          <feComposite operator="over" in="shadow" in2="SourceGraphic" />
        </filter>
      </defs>

      {/* App Icon Squircle Background */}
      <rect
        x="16"
        y="16"
        width="480"
        height="480"
        rx="110"
        fill="url(#bg-gradient)"
        filter="url(#drop-shadow)" />


      {/* Inner Glow / Highlight on Squircle */}
      <rect
        x="16"
        y="16"
        width="480"
        height="480"
        rx="110"
        fill="none"
        stroke="#FFFFFF"
        strokeWidth="4"
        strokeOpacity="0.2" />


      {/* --- CHECKMARK (Behind Owl) --- */}
      <g transform="translate(0, 10)">
        <path
          d="M 130 320 L 220 410 L 410 220"
          fill="none"
          stroke="url(#check-gradient)"
          strokeWidth="44"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter="url(#drop-shadow)" />

        {/* Checkmark Highlight */}
        <path
          d="M 130 320 L 220 410 L 410 220"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.4"
          transform="translate(0, -10)" />

      </g>

      {/* --- OWL CHARACTER --- */}
      <g transform="translate(0, -15)">
        {/* Shadow under owl */}
        <ellipse
          cx="256"
          cy="410"
          rx="110"
          ry="25"
          fill="#178578"
          opacity="0.5"
          filter="blur(8px)" />

        {/* Ear Tufts */}
        <path
          d="M 150 170 Q 130 100 180 120 Q 190 140 200 150 Z"
          fill="#178578" />

        <path
          d="M 362 170 Q 382 100 332 120 Q 322 140 312 150 Z"
          fill="#178578" />

        {/* Main Body */}
        <ellipse
          cx="256"
          cy="250"
          rx="145"
          ry="155"
          fill="url(#body-gradient)" />

        {/* Belly */}
        <ellipse cx="256" cy="285" rx="105" ry="115" fill="#FFF8F0" />
        <ellipse
          cx="256"
          cy="285"
          rx="105"
          ry="115"
          fill="url(#scallop)"
          opacity="0.6" />

        {/* Wings */}
        {/* Left Wing */}
        <path
          d="M 125 230 C 80 270 90 360 135 380 C 155 390 160 340 145 310 C 135 280 145 250 125 230 Z"
          fill="#1A9E8F" />

        {/* Right Wing (Holding Pencil) */}
        <g transform="translate(15, -10)">
          <path
            d="M 370 240 C 415 280 405 370 360 390 C 340 400 335 350 350 320 C 360 290 350 260 370 240 Z"
            fill="#1A9E8F" />


          {/* Pencil */}
          <g transform="translate(365, 300) rotate(-35)">
            {/* Drop shadow for pencil */}
            <rect
              x="-10"
              y="-40"
              width="20"
              height="95"
              rx="4"
              fill="#178578"
              opacity="0.3"
              transform="translate(-4, 4) blur(2px)" />


            {/* Eraser */}
            <rect
              x="-10"
              y="-40"
              width="20"
              height="15"
              rx="4"
              fill="#FF6B6B" />

            {/* Metal Band */}
            <rect x="-10" y="-25" width="20" height="8" fill="#E0E0E0" />
            <rect x="-10" y="-25" width="20" height="3" fill="#CCCCCC" />
            {/* Wood Body */}
            <rect x="-10" y="-17" width="20" height="50" fill="#FFD166" />
            {/* Wood Lines */}
            <line
              x1="-4"
              y1="-17"
              x2="-4"
              y2="33"
              stroke="#E5B85C"
              strokeWidth="2" />

            <line
              x1="4"
              y1="-17"
              x2="4"
              y2="33"
              stroke="#E5B85C"
              strokeWidth="2" />

            {/* Pencil Tip (Wood) */}
            <polygon points="-10,33 10,33 0,55" fill="#F4D0A4" />
            {/* Lead */}
            <polygon points="-3,48 3,48 0,55" fill="#1B2838" />

            {/* Pencil Highlight */}
            <rect
              x="-8"
              y="-38"
              width="4"
              height="68"
              fill="#FFFFFF"
              opacity="0.3"
              rx="2" />

          </g>

          {/* Wing Overlap (to hold pencil) */}
          <path d="M 355 310 C 380 330 370 365 345 355 Z" fill="#178578" />
        </g>
        {/* Eyes */}
        <g transform="translate(0, -15)">
          {/* Left Eye Background */}
          <circle
            cx="195"
            cy="195"
            r="48"
            fill="#FFFFFF"
            filter="url(#inner-shadow)" />

          {/* Right Eye Background */}
          <circle
            cx="317"
            cy="195"
            r="48"
            fill="#FFFFFF"
            filter="url(#inner-shadow)" />


          {/* Left Pupil */}
          <circle cx="202" cy="200" r="24" fill="#1B2838" />
          {/* Right Pupil */}
          <circle cx="310" cy="200" r="24" fill="#1B2838" />

          {/* Eye Highlights */}
          <circle cx="194" cy="190" r="9" fill="#FFFFFF" />
          <circle cx="210" cy="198" r="4" fill="#FFFFFF" />

          <circle cx="302" cy="190" r="9" fill="#FFFFFF" />
          <circle cx="318" cy="198" r="4" fill="#FFFFFF" />

          {/* Eyelids (Subtle expression) */}
          <path
            d="M 145 170 Q 195 150 245 170"
            fill="none"
            stroke="#178578"
            strokeWidth="5"
            strokeLinecap="round" />

          <path
            d="M 267 170 Q 317 150 367 170"
            fill="none"
            stroke="#178578"
            strokeWidth="5"
            strokeLinecap="round" />

        </g>
        {/* Beak */}
        <path d="M 256 225 L 238 198 L 274 198 Z" fill="#FFD166" />
        <path d="M 256 225 L 238 198 L 256 203 Z" fill="#FFB703" />{' '}
        {/* Beak shadow */}
        {/* Smile */}
        <path
          d="M 235 235 Q 256 248 277 235"
          fill="none"
          stroke="#178578"
          strokeWidth="3.5"
          strokeLinecap="round" />

        <circle cx="235" cy="235" r="2" fill="#178578" />
        <circle cx="277" cy="235" r="2" fill="#178578" />
        {/* Feet (Positioned to sit on checkmark) */}
        {/* Left Foot (Lower on checkmark) */}
        <g transform="translate(-5, 20)">
          <path d="M 205 395 C 195 415 225 415 225 395 Z" fill="#EF476F" />
          <path d="M 215 395 C 205 420 235 420 235 395 Z" fill="#EF476F" />
          <path d="M 225 395 C 215 415 245 415 245 395 Z" fill="#EF476F" />
        </g>
        {/* Right Foot (Higher on checkmark slope) */}
        <g transform="translate(15, -15)">
          <path d="M 275 385 C 265 405 295 405 295 385 Z" fill="#EF476F" />
          <path d="M 285 385 C 275 410 305 410 305 385 Z" fill="#EF476F" />
          <path d="M 295 385 C 285 405 315 405 315 385 Z" fill="#EF476F" />
        </g>
      </g>
    </svg>);

}